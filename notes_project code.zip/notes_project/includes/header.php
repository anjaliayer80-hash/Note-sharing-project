<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Notes Sharing</title>
    <!-- Link your CSS file -->
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<hr>
<a href="../public/index.php">Home</a> |

<?php if (isset($_SESSION['user_id'])): ?>
    <a href="../private/dashboard.php">Dashboard</a> |
    <a href="../public/logout.php">Logout</a>
<?php else: ?>
    <a href="../public/login.php">Login</a> |
    <a href="../public/register.php">Register</a>
<?php endif; ?>
<hr>
